Update files for CobraRTP MotronicRT 
Select the necessary file (folder) depending on the version of your board (Rx.x see on the board of the device or in the CobraRTP Utility).
Follow the latest documentation (pdf) for updates.


cobrartp.com
cobrartpteam@gmail.com
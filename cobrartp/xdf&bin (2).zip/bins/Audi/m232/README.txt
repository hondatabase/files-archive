This folder contains base files.

stock_AANABY - Stage 1 tune with SD for a totally standard AAN/ABY engined car.
bigturbo_WMI - Big turbo tune, 2.7 bar boost. Aquamist HFS-3 WMI with failsafe. By comparing the stock and big turbo tunes one can see some of the modifications that need to be made.
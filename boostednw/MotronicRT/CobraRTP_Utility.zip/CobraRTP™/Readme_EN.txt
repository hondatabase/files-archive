CobraRTP Utility

The application for the offline operation of the CobraRTP emulator. It allows you to upload firmware to (from) the emulator in * .bin format, which is convenient if your software does not have the ability to work with the emulator directly.
Also in the CobraRTP Utility you can update and configure the emulator.

System requirements:
Windows XP, Vista, 7, 8, 8.1, 10, 11
* Requires NET Framework 4.x to run.

Changelog:

v3.21
-Fixed a bug in reading FlexFuel readings
-Added the ability to upgrade Honda Edition R10

v3.2
-Added support for new functions of Honda Edition R10
-Minor moments improved

v3.1
-Added the ability to change the target CPU of the ECU to select the type of data byte charging (С167,ST10, Motorola)
-Redesigned interface
-Fixed some points

v3.01
-Fixed incorrect write from buffer to memory for MotronicRT and v3 Pro
-Optimized some points

v3.0
-Added the ability to change the offset of the writing file for FlashOnline
-Added display of file size in HEX
-Improved program interface
-Added vaoids when selecting offset/size
-Fixed minor bugs

v2.2996 
-Solved the problem of switching the interface language 
-Fixed small bugs

v2.995
-Added check for updates for the latest versions of boards
-Improved interface
-Fixed minor bugs
-English language setup default

v2.994
-Added ability to upgrade Honda edition R9 and MotronicRT R6
-Fixed MotronicRT R4 update bug
-English language is set by default
-Improved minor points

v2.993
-Fixed incorrect target ID change for MotronicRT R5
-Improved Datalog testing algorithm

v2.992
-Fixed "Port closed" error during update
-Fixed false battery message (FlashOnline)

v2.99
-Fixed freeze during update in Windows XP, 7, 8 for new board versions (without USB controller ic)

v2.98
-Added support for new versions of Honda Edition R8, FlashOnline R4, MotronicRT R5
-Fixed some nuances


v2.97
-Fixed some bugs
-Added emulator RAM test function

v2.96
-Improved firmware update algorithms

v2.95
-Fixed bugs when exchanging data with FlashOnline via BT channel.
-Fixed BT connection errors
-Updated serial API version
-Fixed some communication bugs

v2.94
-Fixed and redesigned update program algorithm
-Fixed some bugs

v2.93 
-Improved UI 
-Fixed some bugs

v2.92
-Fixed bugs when processing update file under certain conditions
-Fixed memory test algorithm bugs
-Improved interface.

v2.91
-Reworked memory testing algorithm
-Improved adaptation of the interface of the "Configurations" tab
-Fixed some bugs

v2.9
-Added support for data encoding for ECUs with non-standard flash memory connection to the processor (Siemens 5WY (Simk31-43), 5WK (SMG2), MS5150, EMS2000, Sirius32, Simos 3 and others)
-Added device backup battery charge control (only for Rev3.1 and above)
-Improved error system when exchanging data with the emulator
-Improved program interface

v2.81
-Improved Test section

v2.8
-Added the "Address watch" function for FlashOnline (tracing address calls of the ECU processor)
-Manual has been updated 

v2.74
-Added check for device updates online

v2.73
-Fixed update error for MotronicRT R4.0 + via Bluetuth

v2.72
-Fixed bugs in the update loader for ARM processors
-Added check for new updates

v2.71 (10/2021)
-Fixed memory block selection when connecting for 28/29F200
-Optimized uploading in change via Live scanner

v2.7 (08/2021)
-Added the function of automatic file loading when it is changed (saved in a third-party program) - "Live scan"
-Added FlashOnline support
-Added output of the path and name of the open file
-Fixed bugs in the update loader for ARM processors
-Improved datalog testing system
-Improved interface
-Fixed minor bugs

v2.51
-Fixed some points
-Added description

v2.5 (03/16/21)
-Added support for Honda Edition R6.0B (switchable USB / BT datalog)

v2.43 (02/03/2021)
-Added support for official TunerPro ID
-Fixed some bugs

v2.42 (11/25/2020)
-Fix update for ARM versions

v2.41 (11/09/2020)
-Added support for ARM versions of emulators (R4 R6)
-Added device update notification
-Fixed some bugs
-Improved interface and dialogue system

v2.31 (09/12/2020)
-Added support for R4 + revisions
-Fixed errors checking for updates
-Fixed startup error on Win XP

v2.23 (05.17.2020)
-Fixed problem with connection for BT versions.

v2.21 (04.21.2020)
-Add 24ms pulling interval for AUX
-Fixed some points.

v2.2 (04.17.2020)
-Fix server constants
-Fixed some points.

v2.1(16.12.19)
-Add HTS software ID
-Fixed some points.

v2.00(02.11.19)
-Add testing mode (Service->Test)
-Fixed some points.

v1.99(05.10.19)
-Fixed "Bad emulator" when connecting.

v1.98(22.08.19)
-Add Nistune SW ID
-Fixed some points.

v1.97(07.08.19)
-Fixed bug updating BT version
-Fixed some points.

v1.96(25.07.19)
-Fixed some points.

v1.95(23.07.19)
-Fixed some points.

v1.94(23.07.19)
-Fixed some points.

v1.93(16.07.19)
-Fixed some points.

v1.92(12.07.19)
-Fixed some points.

v1.91(12.06.19)
-Fixed some points.

v1.9(26.04.2019)
-Fixed some points.

v1.8 
-Add select "BMTune" 
-Add display the type of device in the configuration window.

v1.7
-Added CobraRTP v3.0 compatiblity
-Analog in test added
-Fixed some points.

v1.6(13.11.18)
- English translation is completed.
- Fixed folder paths.
- improved application performance.

v1.59(07.11.18)
- Improved update file compatibility check.
- Added save file paths.
- Fixed some points.

v1.58(02.11.18)
- Improved interface translation in English.
- Added check for application updates (Help-> About program -> Check update app)
- Fixed minor application errors.

v1.57 (10/29/18)
-Added English interface language (Service -> Language).
-Improved the quality of the application.

v1.56 (10/09/2018)
- Improved error handling.
-Added display of offset and size when selecting the type of ROM.

v1.55 (10/01/2018)
Improved responsiveness of the graphical interface.
-Added loading and displaying the current ID of the target software.
-Added connection report (when device is not updated).
-Added online check of the CobraRTP Utility version.

v1.5 (09/22/2018)
- Added improved write / read options.
-Added online check for updates on the server.
- Improved test connection during read / write.
-Improved the quality of the application.

v1.41 (08.21.2018)
-Added display of the COM port number in the status bar.

v1.4 (08/18/2018)
-Fixed the boot loader.
- Improved quality of work from v1.3 beta.

v1.3 beta (08/16/2018)
-Added item eCtune in the ID of the target software.
-Included support for bluetooth variants of CobraRTP v2.0 boards.
- Improved quality of work.

v1.2 (07/16/2018)
- Available emulator update function.
- Improved quality of work.

v1.1b (06.23.2018):
-Available basic functions, work with files, emulator.
-No emulator update available.
- Testing was carried out with 32 and 64kB firmware.

-------------------------------------------------- -----------------

Add. information:
cobrartp.com/en
cobrartpteam@gmail.com